import pandas as pd

df = pd.read_csv('C:/Users/EANT Alumno/Downloads/MLTB 1/properati_ml.csv')

df.head()

import numpy as np
from sklearn.model_selection import train_test_split

X = df.drop(['price_usd'], axis=1) # variable objetivo
y = df[['price_usd']]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.33, random_state=42)

#---------------------
# Regresion Lineal 
#---------------------
import numpy as np
from sklearn.linear_model import LinearRegression

est_1 = LinearRegression()
est_1.fit(X_train, y_train)

LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None,normalize=False)


from sklearn.metrics import mean_squared_error

price_usd_est_1 = est_1.predict(X_test)

mse = mean_squared_error(y_test, price_usd_est_1)

rmse = np.sqrt(mse)

print(rmse)

#RSE 68834.25
## --> error de 68mil dolares 


#---------------------
#regresión rigde
#---------------------

import numpy as np
from sklearn.linear_model import Ridge

est_2 = Ridge(alpha=1.0)
est_2.fit(X_train, y_train)

Ridge(alpha=1.0, copy_X=True, fit_intercept=True, max_iter=None,
   normalize=False, random_state=None, solver='auto', tol=0.001)

price_usd_est_2 = est_2.predict(X_test)
mse = mean_squared_error(y_test, price_usd_est_2)
rmse = np.sqrt(mse)
print(rmse)

#RSE 69019.32711163783
## --> error de 69mil dolares 



#---------------------
# árbol de decisión con profundidad parámetros default
#---------------------

import numpy as np
from sklearn.tree import DecisionTreeRegressor

est_3 = DecisionTreeRegressor()
est_3.fit(X_train, y_train)
price_usd_est_3 = est_3.predict(X_test)
mse = mean_squared_error(y_test, price_usd_est_3)
rmse = np.sqrt(mse)
print(rmse)

#RSE 74832.5
## --> error de 74mil dolares 


#    regressor = DecisionTreeRegressor(random_state=0, max_depth=d)
#    regressor.fit(X_train, y_train)
#    y_pred_train = regressor.predict(X_train)
#    y_pred_test = regressor.predict(X_test)
#    rmse_train = np.sqrt(mean_squared_error(y_train, y_pred_train))
#    rmse_test = np.sqrt(mean_squared_error(y_test, y_pred_test))
#    rmses_train.append(rmse_train)
#    rmses_test.append(rmse_test)
#    print('El RMSE en training es USD {}'.format(rmse_train.round(2)),d)
#    print('El RMSE en testing es USD {}'.format(rmse_test.round(2)),d) 



#---------------------
# ENSAMBLE 
#---------------------

# 7- Agrupar las predicciones en testing de est_1, est_2 y est_3 en un DataFrame (df_preds).
print(price_usd_est_1.shape, price_usd_est_2.shape, price_usd_est_3.shape)
#(2790, 1) (2790, 1) (2790,)

#lo trabajo para obtener un dataframe.. era un array
price_usd_est_3 = price_usd_est_3.reshape(2790,1)


preds = np.concatenate([price_usd_est_1, price_usd_est_2, price_usd_est_3], axis=1)
#axis=1 indica que es a nivel filas y hace el join por el indice.

#lo convierto a dataframe
df_preds = pd.DataFrame(preds)

#le da nombre a las comlumnas
df_preds.columns = ['price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']
df_preds.head()

   price_usd_est_1  price_usd_est_2  price_usd_est_3
0    103653.253125    111440.762303         82500.12
1    523193.508409    521999.878223        525000.00
2    130432.908673    121958.178921        149000.00
3    262667.419634    260806.798207        235000.00
4    160829.385471    158132.181665        150000.00

#resetea indices

#Comentario
# cuando se divide en training y tests. el estimador toma indices de forma desordenado. 
# Si no reseteamos cuando lo unimos hace mal el join con los valores reales

y_test = y_test.reset_index(drop=True)

df_preds = pd.concat([y_test, df_preds], axis=1)

df_preds.columns = ['price_usd', 'price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']

df_preds.head()


df_preds['price_usd_ensamble_mean'] = df_preds[['price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']].mean(axis=1)
#alternativa
#df_preds['price_usd_ensamble'] = df_preds[['price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']].apply(lambda x,: np.mean(x),axis=1)
df_preds.head()


mse = mean_squared_error(df_preds.price_usd, df_preds.price_usd_ensamble_mean)
rmse = np.sqrt(mse)
print(rmse)
# 63226.6


df_preds['price_usd_ensamble_max'] = df_preds[['price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']].max(axis=1)
#alternativa
#df_preds['price_usd_ensamble'] = df_preds[['price_usd_est_1', 'price_usd_est_2', 'price_usd_est_3']].apply(lambda x,: np.mean(x),axis=1)
df_preds.head()

mse = mean_squared_error(df_preds.price_usd, df_preds.price_usd_ensamble_max)
rmse = np.sqrt(mse)
print(rmse)
# 72400
